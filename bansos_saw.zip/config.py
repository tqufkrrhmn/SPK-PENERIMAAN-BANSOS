SQLALCHEMY_DATABASE_URI = 'mysql://root:@localhost/bansos_saw'
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = 'secretkeyanda'