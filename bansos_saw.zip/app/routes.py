from flask import render_template, redirect, request
from app import app, db
from app.models import Kriteria, Alternatif
from app.saw import normalisasi, hitung_saw

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/hitung')
def hitung():
    data = Alternatif.query.all()
    kriteria = Kriteria.query.all()
    raw = [[d.pendapatan, d.tanggungan, d.tempat_tinggal, d.aset, d.pekerjaan] for d in data]
    jenis = [k.jenis for k in kriteria]
    bobot = [k.bobot for k in kriteria]

    norm = normalisasi(raw, jenis)
    skor = hitung_saw(norm, bobot)
    hasil = list(zip(data, skor))
    hasil.sort(key=lambda x: x[1], reverse=True)
    return render_template('hasil.html', hasil=hasil)