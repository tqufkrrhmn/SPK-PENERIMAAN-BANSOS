def normalisasi(data, jenis_kriteria):
    result = []
    for i in range(len(data[0])):
        kolom = [d[i] for d in data]
        if jenis_kriteria[i] == 'benefit':
            result.append([x / max(kolom) for x in kolom])
        else:
            result.append([min(kolom) / x for x in kolom])
    return list(map(list, zip(*result)))

def hitung_saw(normalized, bobot):
    return [sum(x * y for x, y in zip(alt, bobot)) for alt in normalized]