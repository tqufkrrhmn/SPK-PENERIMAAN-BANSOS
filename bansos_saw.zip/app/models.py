from app import db

class Kriteria(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(100))
    bobot = db.Column(db.Float)
    jenis = db.Column(db.String(10))  # 'benefit' atau 'cost'

class Alternatif(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama_kk = db.Column(db.String(100))
    pendapatan = db.Column(db.Float)
    tanggungan = db.Column(db.Integer)
    tempat_tinggal = db.Column(db.Float)
    aset = db.Column(db.Integer)
    pekerjaan = db.Column(db.Integer)